from django.apps import AppConfig


class OnlinecourseConfig(AppConfig):
    name = 'onlinecourse'
